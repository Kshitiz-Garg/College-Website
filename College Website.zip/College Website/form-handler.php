<?php
$name = $_POST['name'];
$visitor_email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

$email_from= 'kshitizssw@gmail.com';

$email_subject = 'New Form Submission';

$emial_body = "User Name: $name.\n".
            "User Email: $visitor_email.\n" 
             "Subject: $subject.\n".
             "User Message: $message .\n;"

$to = 'kshitizssw@gmail.com';

$headers = "form: $email_form \r\n";

$headers = "Reply-To: $visitor_email \r\n";

mail($to,$email_subject,$emial_body,$headers);

header("Location. contact.html");
?>